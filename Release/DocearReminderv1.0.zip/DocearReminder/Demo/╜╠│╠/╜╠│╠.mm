<map version="freeplane 1.3.0" project="17DAB3A24CC7NGK3HWY5ERX3AURZZAJ2PT99" project_last_home="file:/E:/yixiaozi/">
  <!--To view this file, download Docear - The Academic Literature Suite from http://www.docear.org -->
  <node TEXT="&#x6559;&#x7A0B;" FOLDED="false" ID="ID_896571670" CREATED="1640982375985" MODIFIED="1640982375985">
    <hook NAME="AutomaticEdgeColor" COUNTER="0" />
    <node TEXT="2022">
      <node TEXT="1">
        <node TEXT="1">
          <node TEXT="o&#x662F;&#x5B8C;&#x6210;&#x4EFB;&#x52A1;" CREATED="1640982408391" MODIFIED="1640982408391" TASKLEVEL="1" TASKTIME="0" ID="f5ca11a9-5244-4547-b960-d2cff347b1f4">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982408391" />
            </hook>
          </node>
          <node TEXT="&#x6309;P&#x5219;&#x4F1A;&#x5C06;&#x4EFB;&#x52A1;&#x63A8;&#x8FDF;&#xFF0C;&#x4E00;&#x822C;&#x4EFB;&#x52A1;&#x4E3A;&#x4E00;&#x5929;&#xFF0C;&#x5468;&#x671F;&#x4EFB;&#x52A1;&#x6309;&#x5468;&#x671F;&#x63A8;&#x8FDF;" CREATED="1640982533468" MODIFIED="1640982533468" TASKLEVEL="1" TASKTIME="0" ID="7af744b8-9834-4f6d-88b3-29985a29cd6f">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982533468" />
            </hook>
          </node>
          <node TEXT="&#x53F3;&#x8FB9;&#x8BBE;&#x7F6E;&#x5468;&#x671F;&#x53F3;&#x8FB9;&#x5C31;&#x662F;&#x8BBE;&#x7F6E;&#x5468;&#x671F;&#x7684;&#x5730;&#x65B9;&#xFF0C;&#x7A0D;&#x540E;&#x6211;&#x4F1A;&#x7ED9;&#x51FA;&#x8BF4;&#x660E;&#x56FE;" CREATED="1640982586664" MODIFIED="1640982586664" ID="da0072a3-c07a-4e17-80a4-e2200b3791a7" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982586664" />
            </hook>
          </node>
          <node TEXT="&#x5982;&#x679C;&#x60F3;&#x6DFB;&#x52A0;&#x4EFB;&#x52A1;&#xFF0C;&#x53EF;&#x4EE5;&#x518D;&#x8F93;&#x5165;&#x6846;&#x5185;&#x8F93;&#x5165;&#x4EFB;&#x52A1;&#x540D;&#x79F0;&#x7136;&#x540E;At&#x6BD4;&#x5982;&#x6559;&#x7A0B;&#xFF0C;&#x56DE;&#x8F66;&#x5C31;&#x53EF;&#x4EE5;&#x4E86;" CREATED="1640982656940" MODIFIED="1640982656940" ID="a2dd6e67-eeba-43ec-86fa-6840d901be63" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982656940" />
            </hook>
          </node>
          <node TEXT="1&#x548C;2&#x53EF;&#x4EE5;&#x5207;&#x6362;&#x9009;&#x4E2D;&#x72B6;&#x6001;" CREATED="1640982760969" MODIFIED="1640982760969" ID="457d1977-6207-4273-8c93-4bb46bf3e509" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982760969" />
            </hook>
            <node TEXT="j,k&#x5219;&#x662F;&#x5411;&#x4E0A;&#x5411;&#x4E0B;" CREATED="1640982778892" MODIFIED="1640982778892" ID="4c4a28e2-fcc4-43dc-8455-17085f1f331e" TASKLEVEL="1" />
          </node>
          <node TEXT="j,k&#x5219;&#x662F;&#x5411;&#x4E0A;&#x5411;&#x4E0B;" CREATED="1640982799578" MODIFIED="1640982799578" ID="7535c8f2-691e-4929-abdf-daf010d73c76" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982799578" />
            </hook>
          </node>
          <node TEXT="5&#x53EF;&#x4EE5;&#x5207;&#x6362;&#x770B;&#x5468;&#x671F;&#x4EFB;&#x52A1;&#x8FD8;&#x662F;&#x5355;&#x6B21;&#x4EFB;&#x52A1;" CREATED="1640982852634" MODIFIED="1640982852634" ID="3f17e75e-da30-4a23-8f95-b6f16930be26" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982852634" />
            </hook>
            <node TEXT="&#x4F60;&#x4E5F;&#x53EF;&#x4EE5;&#x6309;a" CREATED="1640982964500" MODIFIED="1640982964500" ID="20d44f00-9380-4609-b08b-ea7450a3dcf3" TASKLEVEL="1" />
          </node>
          <node TEXT="6&#x53EF;&#x4EE5;&#x770B;&#x67D0;&#x4E9B;&#x4E0D;&#x91CD;&#x8981;&#x4EFB;&#x52A1;" CREATED="1640982871893" MODIFIED="1640982871893" ID="26037389-3414-4f8e-a933-c60883b02005" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982871893" />
            </hook>
          </node>
          <node TEXT="&#x8BBE;&#x7F6E;&#x4E0D;&#x91CD;&#x8981;&#x4EFB;&#x52A1;&#x7684;&#x65B9;&#x6CD5;&#x662F;&#x4EFB;&#x52A1;&#x9009;&#x4E2D;&#x65F6;&#x6309;z,&#x7136;&#x540E;&#x6309;6&#x5C31;&#x53EF;&#x4EE5;&#x627E;&#x5230;&#x5B83;&#x4E86;" CREATED="1640982922526" MODIFIED="1640982922526" ID="1a7d00c0-b992-4313-a270-aee7078088d6" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982922526" />
            </hook>
          </node>
          <node TEXT="q&#x6362;&#x51FA;&#x65E5;&#x5386;" CREATED="1640982990852" MODIFIED="1640982990852" ID="afc5d3f1-07c3-48a3-acd4-22983290fc05" TASKTIME="20" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640982990852" />
            </hook>
          </node>
          <node TEXT="&#x5728;&#x8F93;&#x5165;&#x6846;&#x8F93;&#x5165;tool,showlog,j,k&#x5219;&#x662F;&#x5411;&#x4E0A;&#x5411;&#x4E0B;se,j,k&#x5219;&#x662F;&#x5411;&#x4E0A;&#x5411;&#x4E0B;F,j,k&#x5219;&#x662F;&#x5411;&#x4E0A;&#x5411;&#x4E0B;f,o=0.5,t&#x756A;&#x8304;&#x6C41;&#xFF0C;T&#x6B63;&#x756A;&#x8304;&#x949F;&#x5219;&#x4F1A;&#x6709;&#x5BF9;&#x5E94;&#x529F;&#x80FD;&#x81EA;&#x5DF1;&#x7814;&#x7A76;&#x5427;" CREATED="1640983072523" MODIFIED="1640983072523" ID="6c1aa95a-ad25-49e2-885f-08ecdfa360f0" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983072523" />
            </hook>
          </node>
          <node TEXT="&#x53F3;&#x4FA7;&#x6709;&#x4E00;&#x4E2A;&#x6807;&#x7B7E;&#x4E91;&#xFF0C;&#x5982;&#x679C;&#x4F60;&#x60F3;&#x6DFB;&#x52A0;&#x53EF;&#x4EE5;&#x624B;&#x52A8;&#x6DFB;&#x52A0;&#xFF0C;&#x4F46;&#x597D;&#x50CF;&#x4E0D;&#x4F1A;&#x81EA;&#x52A8;&#x4FDD;&#x5B58;" CREATED="1640983116150" MODIFIED="1640983116150" ID="7c7765fe-1258-4f00-9200-bc72429568c0" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983116150" />
            </hook>
          </node>
          <node TEXT="&#x6807;&#x7B7E;&#x4E91;&#x5982;&#x679C;&#x60F3;&#x6DFB;&#x52A0;&#x53EF;&#x4EE5;&#x8F93;&#x5165;g&#x7136;&#x540E;&#x8F93;&#x5165;&#x60F3;&#x6DFB;&#x52A0;&#x7684;&#x6807;&#x7B7E;&#xFF0C;&#x8BD5;&#x4E00;&#x8BD5;&#x5427;" CREATED="1640983162078" MODIFIED="1640983162078" TASKLEVEL="1" TASKTIME="0" ID="f8c7a68f-7da8-4b63-8d86-cd2ebc687155">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983162078" />
            </hook>
          </node>
          <node TEXT="&#x5230;&#x8FD9;&#x91CC;&#x4F60;&#x5E94;&#x8BE5;&#x53BB;&#x770B;&#x4E00;&#x4E0B;config.ini&#x6587;&#x4EF6;&#x4E86;&#xFF0C;&#x5982;&#x679C;&#x6709;&#x8BF4;&#x660E;&#x7591;&#x95EE;&#xFF0C;&#x540E;&#x7EED;&#x6211;&#x4F1A;&#x7ED9;&#x51FA;&#x8BF4;&#x660E;&#x6587;&#x6863;" CREATED="1640983213492" MODIFIED="1640983213492" ID="11b5d7d6-1407-46ef-b460-f3187b7787bd" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983213492" />
            </hook>
          </node>
          <node TEXT="&#x8F6F;&#x4EF6;&#x57FA;&#x4E8E;&#x601D;&#x7EF4;&#x5BFC;&#x56FE;&#xFF0C;&#x6240;&#x4EE5;&#x8BF7;&#x4F7F;&#x7528;docear-1.2.0.0_stable_build291&#x6253;&#x5F00;&#x601D;&#x7EF4;&#x5BFC;&#x56FE;&#xFF0C;&#x8F6F;&#x4EF6;&#x6211;&#x4E5F;&#x4F1A;&#x5206;&#x4EAB;&#x7684;" CREATED="1640983292263" MODIFIED="1640983292263" ID="8ec94778-236e-4abe-b862-e0331bf9be48" TASKTIME="0" TASKLEVEL="5">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983292263" />
            </hook>
          </node>
          <node TEXT="&#x601D;&#x7EF4;&#x5BFC;&#x56FE;&#x6253;&#x5F00;&#x6BD4;&#x8F83;&#x7E41;&#x7410;&#xFF0C;&#x4F60;&#x53EF;&#x4EE5;&#x6309;N&#xFF0C;B&#xFF0C;Shift+N&#x67E5;&#x770B;&#x5F53;&#x524D;&#x5BFC;&#x56FE;&#xFF0C;&#x5177;&#x4F53;&#x8BF7;&#x81EA;&#x5DF1;&#x67E5;&#x770B;&#x6548;&#x679C;" CREATED="1640983347537" MODIFIED="1640983347537" ID="541d6a1c-70ff-4c1b-968f-9cb6629d212e" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983347537" />
            </hook>
          </node>
          <node TEXT="&#x8F6F;&#x4EF6;&#x4E0B;&#x65B9;&#x6709;&#x4E00;&#x4E9B;&#x6570;&#x5B57;&#xFF0C;&#x4F60;&#x80FD;&#x731C;&#x51FA;&#x4ED6;&#x4EEC;&#x65F6;&#x5E72;&#x4EC0;&#x4E48;&#x7684;&#x5417;&#xFF1F;" CREATED="1640983396912" MODIFIED="1640983396912" TASKLEVEL="1" TASKTIME="0" ID="f9dfcf9c-8479-40d1-b774-bebc14a0a5d9">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983396912" />
            </hook>
          </node>
          <node TEXT="&#x8F6F;&#x4EF6;&#x6709;&#x8BE6;&#x7EC6;&#x7684;&#x4F7F;&#x7528;&#x8BB0;&#x5F55;&#xFF0C;&#x52A0;&#x5BC6;&#x4FDD;&#x5B58;&#x4E86;&#xFF0C;&#x5BC6;&#x5319;&#x65F6;&#x914D;&#x7F6E;&#x6587;&#x4EF6;&#x4E2D;&#x7684;abc" CREATED="1640983699696" MODIFIED="1640983699696" ID="9a7a863f-dd01-4c0c-a4f8-3b93701566c8" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983699696" />
            </hook>
          </node>
          <node TEXT="&#x5BF9;&#x4E86;&#xFF0C;&#x5FD8;&#x8BB0;&#x8BF4;&#x4E86;&#xFF0C;&#x8F6F;&#x4EF6;&#x53EF;&#x4EE5;&#x6309;Shift+Space&#x5524;&#x51FA;&#x6216;&#x9690;&#x85CF;" CREATED="1640983735710" MODIFIED="1640983735710" ID="fe943e51-eecf-4000-97e9-7fc8c14c3576" TASKTIME="20" TASKLEVEL="8">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983735710" />
            </hook>
          </node>
          <node TEXT="&#x5982;&#x679C;&#x4F60;&#x60F3;&#x8BBE;&#x7F6E;&#x4EFB;&#x52A1;&#x7684;&#x65F6;&#x95F4;&#xFF0C;&#x65F6;&#x957F;&#xFF0C;&#x7B49;&#x7EA7;&#x53EF;&#x4EE5;&#x5C1D;&#x8BD5;&#x6309;&#x4E0B;t,m,l" CREATED="1640983786891" MODIFIED="1640983786891" ID="2af7e4f9-77af-43e1-97d3-5e0d180edf54" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983786891" />
            </hook>
          </node>
          <node TEXT="&#x6B64;&#x8F6F;&#x4EF6;&#x662F;&#x6211;&#x4E2A;&#x4EBA;&#x6BCF;&#x5929;&#x90FD;&#x4F1A;&#x4F7F;&#x7528;&#x7684;&#x5DE5;&#x5177;&#xFF0C;&#x5206;&#x4EAB;&#x51FA;&#x6765;&#x4E5F;&#x662F;&#x5E0C;&#x671B;&#x6709;&#x4EBA;&#x559C;&#x6B22;&#xFF0C;&#x5982;&#x679C;&#x4F60;&#x771F;&#x7684;&#x9700;&#x8981;&#x5B83;&#xFF0C;&#x6211;&#x4F1A;&#x5E2E;&#x4F60;&#x9002;&#x5E94;&#x5B83;&#xFF0C;&#x867D;&#x7136;&#x8FD9;&#x786E;&#x5B9E;&#x9700;&#x8981;&#x4E00;&#x4E9B;&#x65F6;&#x95F4;" CREATED="1640983876178" MODIFIED="1640983876178" TASKLEVEL="1" TASKTIME="0" ID="2b365ac3-fb91-427d-8c8a-0a523c1bb215">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983876178" />
            </hook>
          </node>
          <node TEXT="&#x8F6F;&#x4EF6;&#x8FD8;&#x6709;&#x5F88;&#x591A;&#x4E0D;&#x5B8C;&#x5584;&#x7684;&#x5730;&#x65B9;&#xFF0C;&#x4E0D;&#x8FC7;&#x76EE;&#x524D;&#x4F5C;&#x4E3A;&#x4E00;&#x4E2A;&#x5DE5;&#x5177;&#x6765;&#x8BF4;&#x5DF2;&#x7ECF;&#x975E;&#x5E38;&#x597D;&#x7528;&#x4E86;" CREATED="1640983953355" MODIFIED="1640983953355" ID="b69702d2-fb71-47fa-8b71-a202760bbe51" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640983953356" />
            </hook>
          </node>
          <node TEXT="&#x8F6F;&#x4EF6;&#x96C6;&#x6210;&#x4E86;&#x5FEB;&#x901F;&#x542F;&#x52A8;&#x529F;&#x80FD;&#xFF0C;&#x5728;&#x914D;&#x7F6E;&#x6587;&#x4EF6;&#x91CC;&#x53EF;&#x4EE5;&#x586B;&#x5199;&#x9700;&#x8981;&#x7D22;&#x5F15;&#x7684;&#x6587;&#x4EF6;&#x5939;&#xFF0C;&#x6D4F;&#x89C8;&#x5668;&#x4E66;&#x7B7E;&#x6587;&#x4EF6;" CREATED="1640984024891" MODIFIED="1640984024891" TASKLEVEL="1" TASKTIME="0" ID="4775ae00-e212-4265-a022-9abe4c82d509">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640984024891" />
            </hook>
          </node>
          <node TEXT="&#x8F93;&#x5165;&#x6846;&#x53EF;&#x80FD;&#x662F;&#x4F60;&#x7ECF;&#x5E38;&#x9700;&#x8981;&#x4F7F;&#x7528;&#x7684;&#x5730;&#x65B9;&#xFF0C;&#x56E0;&#x4E3A;&#x5F88;&#x591A;&#x547D;&#x4EE4;&#x548C;&#x529F;&#x80FD;&#x90FD;&#x662F;&#x8F93;&#x5165;&#x6846;&#x6DFB;&#x52A0;&#x67D0;&#x4E9B;&#x5B57;&#x7B26;&#x5524;&#x9192;&#x7684;" CREATED="1640984085295" MODIFIED="1640984085295" TASKLEVEL="1" TASKTIME="0" ID="a39b4c3d-ceb3-4a5f-9be6-0347a7b83f16">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640984085295" />
            </hook>
          </node>
          <node TEXT="&#x6BD4;&#x5982;1&#x5DE6;&#x8FB9;&#x7684;&#x952E;&#x662F;&#x6700;&#x8FD1;&#x6253;&#x5F00;&#x6587;&#x6863;&#xFF0C;at,#,*,&#x5206;&#x522B;&#x5BF9;&#x5E94;&#x5BFC;&#x56FE;&#xFF0C;&#x5DE5;&#x4F5C;&#x533A;&#x6587;&#x6863;&#xFF0C;&#x6240;&#x6709;&#x6587;&#x4EF6;&#x3002;" CREATED="1640984253644" MODIFIED="1640984253644" TASKLEVEL="1" TASKTIME="0" ID="1377b932-91a7-4ee0-9a9e-03733a16155c">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640984253644" />
            </hook>
          </node>
          <node TEXT="F1-F12&#x67D0;&#x4E9B;&#x4E5F;&#x6709;&#x7279;&#x5B9A;&#x529F;&#x80FD;&#xFF0C;F1,&#x5E2E;&#x52A9;&#xFF0C;F&#x91CD;&#x547D;&#x540D;&#xFF0C;F5&#x5237;&#x65B0;&#xFF0C;F11&#x63A8;&#x51FA;&#xFF0C;F12&#x64CD;&#x4F5C;&#x8BB0;&#x5F55;&#x3002;" CREATED="1640984346930" MODIFIED="1640984346930" TASKLEVEL="1" TASKTIME="0" ID="d3143f60-a91a-462f-937b-7279e0b7da9d">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640984346930" />
            </hook>
          </node>
          <node TEXT="&#x5728;&#x4EFB;&#x52A1;&#x4E0A;&#x65F6;&#x6309;x,&#x5219;&#x5C06;&#x5176;&#x8BBE;&#x7F6E;&#x4E3A;&#x91CD;&#x70B9;&#x4EFB;&#x52A1;" CREATED="1640984403554" MODIFIED="1640984403554" ID="0029029b-d198-4cec-bf36-14af7889ddf6" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640984403554" />
            </hook>
          </node>
          <node TEXT="&#x8F93;&#x5165;&#x6846;&#x65E0;&#x8BBA;&#x4F55;&#x65F6;&#x8F93;&#x5165;&#x4E09;&#x4E2A;j,&#x4F1A;&#x5E2E;&#x4F60;&#x91CD;&#x65B0;&#x56DE;&#x5230;&#x4EFB;&#x52A1;&#x680F;&#xFF0C;&#x5927;&#x90E8;&#x5206;&#x65F6;&#x5019;&#x4F60;&#x4E0D;&#x9700;&#x8981;&#x4F7F;&#x7528;&#x9F20;&#x6807;&#x3002;" CREATED="1640984465182" MODIFIED="1640984465182" TASKLEVEL="1" TASKTIME="0" ID="2ff7484c-d484-4fd4-8c91-0460b73fc85d">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640984465182" />
            </hook>
          </node>
          <node TEXT="&#x4ECA;&#x5929;&#x5148;&#x5230;&#x8FD9;&#x91CC;&#x5427;&#xFF0C;&#x5982;&#x679C;&#x4F60;&#x771F;&#x7684;&#x6709;&#x5174;&#x8DA3;&#x8BA9;&#x8FD9;&#x6B3E;&#x8F6F;&#x4EF6;&#x4ECA;&#x540E;&#x5E2E;&#x52A9;&#x4F60;&#xFF0C;&#x90A3;&#x6211;&#x5F88;&#x4E50;&#x610F;&#x63D0;&#x4F9B;&#x66F4;&#x591A;&#x6307;&#x5BFC;&#x3002;" CREATED="1640984568361" MODIFIED="1640984568361" ID="066a5708-0983-496e-bfbf-144a8d37f019" TASKTIME="0" TASKLEVEL="5">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640984568361" />
            </hook>
          </node>
          <node TEXT="&#x8F6F;&#x4EF6;&#x8FD8;&#x6709;&#x5F88;&#x591A;&#x4E0D;&#x5B8C;&#x7F8E;&#x7684;&#x5730;&#x65B9;&#xFF0C;&#x53EF;&#x662F;&#x8FD9;&#x662F;&#x4E00;&#x4E2A;&#x5DE5;&#x5177;&#xFF0C;&#x4E0D;&#x662F;&#x4E00;&#x4E2A;&#x4EA7;&#x54C1;&#xFF0C;&#x8BF7;&#x4E0D;&#x8981;&#x592A;&#x4E25;&#x683C;&#x8BC4;&#x4EF7;&#x5B83;" CREATED="1640985038063" MODIFIED="1640985038063" TASKLEVEL="1" TASKTIME="0" ID="0f6d9ac5-9572-4d33-a26d-f2f4628422b3">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640985038063" />
            </hook>
          </node>
          <node TEXT="&#x6700;&#x540E;&#xFF0C;&#x5E0C;&#x671B;&#x4F60;&#x559C;&#x6B22;&#x3002;" CREATED="1640985062410" MODIFIED="1640985062411" ID="91dddaf7-207e-460a-938d-fbeb0128320a" TASKLEVEL="1">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640985062411" />
            </hook>
          </node>
          <node TEXT="&#x8F6F;&#x4EF6;&#x8FD8;&#x4F1A;&#x8BB0;&#x5F55;&#x526A;&#x5207;&#x677F;&#x64CD;&#x4F5C;&#xFF0C;&#x5728;&#x6587;&#x4EF6;&#x5939;&#x7684;2022&#x5E74;&#x5185;&#xFF0C;&#x8BF7;&#x76F8;&#x4FE1;&#x4F60;&#x7684;&#x6570;&#x636E;&#x7EDD;&#x5BF9;&#x65F6;&#x5B89;&#x5168;&#x7684;&#x3002;&#x6B64;&#x8F6F;&#x4EF6;&#x4E0D;&#x4F1A;&#x6709;&#x4EFB;&#x4F55;&#x8054;&#x7F51;&#x884C;&#x4E3A;&#xFF0C;&#x6E90;&#x7801;&#x5DF2;&#x7ECF;&#x516C;&#x5F00;&#xFF0C;&#x76F8;&#x4FE1;&#x6709;&#x5FC3;&#x7684;&#x4EBA;&#x4E00;&#x5B9A;&#x80FD;&#x627E;&#x5230;&#x3002;" CREATED="1640985311368" MODIFIED="1640985311368" TASKLEVEL="1" TASKTIME="0" ID="82db03aa-6d66-4ed1-a8cd-07701d6fff0d">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640985311368" />
            </hook>
          </node>
        </node>
      </node>
    </node>
  </node>
</map>