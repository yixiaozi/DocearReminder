<map version="docear 1.1" project="17DAB3A24CC7NGK3HWY5ERX3AURZZAJ2PT99" project_last_home="file:/E:/yixiaozi/" dcr_id="1640514880395_at1qtm6ajg68l9h2q3an2yp25">
  <!--To view this file, download Docear - The Academic Literature Suite from http://www.docear.org -->
  <node TEXT="calander" FOLDED="false" ID="ID_1823483544" CREATED="1640347265596" MODIFIED="1640347265596">
    <hook NAME="AutomaticEdgeColor" COUNTER="0" />
    <hook NAME="MapStyle">
      <properties show_note_icons="true" />
      <map_styles>
        <stylenode LOCALIZED_TEXT="styles.root_node">
          <stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right">
            <stylenode LOCALIZED_TEXT="default" MAX_WIDTH="600" COLOR="#000000" STYLE="as_parent">
              <font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false" />
            </stylenode>
            <stylenode LOCALIZED_TEXT="defaultstyle.details" />
            <stylenode LOCALIZED_TEXT="defaultstyle.note" />
            <stylenode LOCALIZED_TEXT="defaultstyle.floating">
              <edge STYLE="hide_edge" />
              <cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT" />
            </stylenode>
          </stylenode>
          <stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right">
            <stylenode LOCALIZED_TEXT="styles.topic" COLOR="#18898b" STYLE="fork">
              <font NAME="Liberation Sans" SIZE="10" BOLD="true" />
            </stylenode>
            <stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cc3300" STYLE="fork">
              <font NAME="Liberation Sans" SIZE="10" BOLD="true" />
            </stylenode>
            <stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#669900">
              <font NAME="Liberation Sans" SIZE="10" BOLD="true" />
            </stylenode>
            <stylenode LOCALIZED_TEXT="styles.important">
              <icon BUILTIN="yes" />
            </stylenode>
          </stylenode>
          <stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right">
            <stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000">
              <font SIZE="18" />
            </stylenode>
            <stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#0033ff">
              <font SIZE="16" />
            </stylenode>
            <stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#00b439">
              <font SIZE="14" />
            </stylenode>
            <stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#990000">
              <font SIZE="12" />
            </stylenode>
            <stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#111111">
              <font SIZE="10" />
            </stylenode>
          </stylenode>
        </stylenode>
      </map_styles>
    </hook>
    <node TEXT="2021" POSITION="right" ID="ID_1493130691" CREATED="1640514880377" MODIFIED="1640514880377">
      <node TEXT="12" ID="ID_647978986" CREATED="1640514880377" MODIFIED="1640514880377">
        <node TEXT="26" ID="ID_58211744" CREATED="1640514880377" MODIFIED="1640514880377">
          <node TEXT="task default" ID="ID_681177332" CREATED="1640514893948" MODIFIED="1640514909160" TASKTIME="0" TASKLEVEL="8">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640514900000" PERIOD="1" UNIT="DAY" />
            </hook>
            <node TEXT="&#x8F6F;&#x4EF6;&#x8FD8;&#x4F1A;&#x8BB0;&#x5F55;&#x526A;&#x5207;&#x677F;&#x64CD;&#x4F5C;&#xFF0C;&#x5728;&#x6587;&#x4EF6;&#x5939;&#x7684;2022&#x5E74;&#x5185;&#xFF0C;&#x8BF7;&#x76F8;&#x4FE1;&#x4F60;&#x7684;&#x6570;&#x636E;&#x7EDD;&#x5BF9;&#x65F6;&#x5B89;&#x5168;&#x7684;&#x3002;&#x6B64;&#x8F6F;&#x4EF6;&#x4E0D;&#x4F1A;&#x6709;&#x4EFB;&#x4F55;&#x8054;&#x7F51;&#x884C;&#x4E3A;&#xFF0C;&#x6E90;&#x7801;&#x5DF2;&#x7ECF;&#x516C;&#x5F00;&#xFF0C;&#x76F8;&#x4FE1;&#x6709;&#x5FC3;&#x7684;&#x4EBA;&#x4E00;&#x5B9A;&#x80FD;&#x627E;&#x5230;&#x3002;" CREATED="1640985299661" MODIFIED="1640985299661" ID="85d8a180-0f66-4bd5-840b-2357c201caf2" TASKLEVEL="1" />
          </node>
        </node>
        <node TEXT="29">
          <node TEXT="&#x4F60;&#x597D;&#x5417;" CREATED="1640730516873" MODIFIED="1640730516873" ID="988ade3f-c03d-43f1-a52e-8dccc0c67837" TASKLEVEL="1" TASKTIME="300">
            <icon BUILTIN="button_ok" />
          </node>
          <node TEXT="&#x4ECA;&#x5929;&#xFF0C;&#x5F88;&#x5F00;&#x5FC3;" CREATED="1640730560195" MODIFIED="1640730560195" ID="6f5e75b2-91bc-4785-b082-7782f87ccb5a" TASKLEVEL="1" TASKTIME="210">
            <icon BUILTIN="button_ok" />
          </node>
          <node TEXT="&#x5F88;&#x5F00;&#x5FC3;" CREATED="1640732514076" MODIFIED="1640732514076" ID="12b3e461-7907-4b4d-b499-171419e7e444" TASKLEVEL="1" TASKTIME="180">
            <icon BUILTIN="button_ok" />
          </node>
          <node TEXT="&#x4F60;&#x77E5;&#x9053;&#x5417;&#xD;&#xA;" CREATED="1640732525091" MODIFIED="1640732525091" ID="50c313cd-d690-466b-9f67-a0d6165b9372" TASKLEVEL="1" TASKTIME="30">
            <icon BUILTIN="button_ok" />
          </node>
        </node>
        <node TEXT="31">
          <node TEXT="&#x54C8;&#x54C8;&#x54C8;&#xD;&#xA;" CREATED="1640923200000" MODIFIED="1640923200000" ID="cd0bba0c-82c9-436a-b390-bb7688566e77" TASKLEVEL="1" TASKTIME="30">
            <icon BUILTIN="button_ok" />
          </node>
        </node>
      </node>
    </node>
    <node TEXT="2022">
      <node TEXT="1">
        <node TEXT="1">
          <node TEXT="&#x65B0;&#x7684;&#x4E00;&#x5E74;&#x65B0;&#x7684;&#x5F00;&#x59CB;&#xFF01;" CREATED="1640977200000" MODIFIED="1640977200000" ID="42f7c7c4-2031-4685-b4ac-e1f9b010025d" TASKTIME="240" TASKLEVEL="6">
            <hook NAME="plugins/TimeManagementReminder.xml">
              <Parameters REMINDUSERAT="1640977200000" />
            </hook>
          </node>
        </node>
      </node>
    </node>
  </node>
</map>