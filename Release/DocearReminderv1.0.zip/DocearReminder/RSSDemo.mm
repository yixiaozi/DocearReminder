<map version="docear 1.1" project="17858D0CFE52BZC70177LHV2B9241TPUCLQI" project_last_home="file:/C:/Users/wangy/Docear/projects/My%20Thesis" dcr_id="1631337886461_596xra7r24jenhlu9nw9ab8ah">
<!--To view this file, download Docear - The Academic Literature Suite from http://www.docear.org -->
<node TEXT="RSSDemo" FOLDED="false" ID="ID_148977278" CREATED="1631337886424" MODIFIED="1631337886426">
<hook NAME="AutomaticEdgeColor" COUNTER="2"/>
<hook NAME="MapStyle">
    <properties show_note_icons="true"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node">
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right">
<stylenode LOCALIZED_TEXT="default" MAX_WIDTH="1000" MIN_WIDTH="20" STYLE="as_parent">
<font NAME="YouYuan" SIZE="12" BOLD="false" ITALIC="false"/>
<edge STYLE="linear" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details"/>
<stylenode LOCALIZED_TEXT="defaultstyle.note"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#18898b" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cc3300" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#669900">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#0033ff">
<font SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#00b439">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#990000">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#111111">
<font SIZE="10"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="####URL####" POSITION="left" ID="ID_1408241853" CREATED="1631337888832" ISURL="true" MODIFIED="1631337898475" MOVED="1631339963250">
<edge COLOR="#ff0000"/>
</node>
<node TEXT="&#x6587;&#x7ae0;" POSITION="right" ID="ID_1319471946" CREATED="1631339959637" MODIFIED="1631339959644" MOVED="1631339961601">
<edge COLOR="#0000ff"/>
</node>
</node>
</map>
