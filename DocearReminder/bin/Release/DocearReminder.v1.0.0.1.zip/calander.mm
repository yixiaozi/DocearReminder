<map version="freeplane 1.3.0" project="17DAB3A24CC7NGK3HWY5ERX3AURZZAJ2PT99" project_last_home="file:/E:/yixiaozi/">
<!--To view this file, download Docear - The Academic Literature Suite from http://www.docear.org -->
<node TEXT="calander" FOLDED="false" ID="ID_1823483544" CREATED="1640347265596" MODIFIED="1640347265596">
<hook NAME="AutomaticEdgeColor" COUNTER="0"/>
</node>
</map>
